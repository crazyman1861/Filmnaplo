const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const cors = require('cors');

const app = express();

app.use('/static', express.static(path.join(__dirname, 'public')));

const servePage = (page) => (req,res) => res.sendFile(path.join(__dirname, 'public', 'html', `${page}.html`));

app.get('/', servePage('index'));
app.get('/login.html', servePage('login'));
app.get('/felkapot.html', servePage('felkapot'));
app.get('/naplo.html', servePage('naplo'));
app.get('/registration.html', servePage('registration'));
app.get('/index.html', servePage('index'));

const port = 3000;

app.listen(port, () => {
    console.log(`http://localhost:${port}`) ;
});