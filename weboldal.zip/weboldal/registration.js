document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    const username = document.getElementById('username');
    const email = document.getElementById('email');
    const password = document.getElementById('password');
    const confirmPassword = document.getElementById('confirm-password');
    const submitButton = form.querySelector('button');
    
    // Hibaüzenetek div-ek létrehozása
    const usernameError = document.createElement('div');
    const emailError = document.createElement('div');
    const passwordError = document.createElement('div');
    const confirmPasswordError = document.createElement('div');
    form.appendChild(usernameError);
    form.appendChild(emailError);
    form.appendChild(passwordError);
    form.appendChild(confirmPasswordError);
    
    // Hibaüzenetek stílusai
    const errorStyle = 'color: red; font-size: 1rem; margin-top: -15px;';

    usernameError.style.cssText = errorStyle;
    emailError.style.cssText = errorStyle;
    passwordError.style.cssText = errorStyle;
    confirmPasswordError.style.cssText = errorStyle;
    
    // Form submit kezelése
    form.addEventListener('submit', function (e) {
        e.preventDefault(); // A form elküldése megelőzve
        
        // Előző hibaüzenetek eltávolítása
        usernameError.textContent = '';
        emailError.textContent = '';
        passwordError.textContent = '';
        confirmPasswordError.textContent = '';

        let valid = true;

        // Felhasználónév ellenőrzése
        if (username.value.trim() === '') {
            usernameError.textContent = 'Felhasználónév nem lehet üres!';
            valid = false;
        }

        // Email ellenőrzése
        const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
        if (!emailPattern.test(email.value)) {
            emailError.textContent = 'Érvénytelen e-mail cím!';
            valid = false;
        }

        // Jelszó ellenőrzése
        if (password.value.length < 6) {
            passwordError.textContent = 'A jelszónak legalább 6 karakter hosszúnak kell lennie!';
            valid = false;
        }

        // Jelszó megerősítése
        if (password.value !== confirmPassword.value) {
            confirmPasswordError.textContent = 'A két jelszó nem egyezik!';
            valid = false;
        }

        // Ha minden valid, akkor elküldjük a formot
        if (valid) {
            form.submit(); // Ezt a sorot eltávolíthatod, ha nem valódi form elküldést szeretnél, csak tesztelni
        }
    });
});
