  // Film hozzáadás logika
document.getElementById('film-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const title = document.getElementById('film-title').value;
    const director = document.getElementById('director').value;
    const year = document.getElementById('year').value;
    const genre = document.getElementById('genre').value;

    const filmList = document.getElementById('film-collection');

    const newFilm = document.createElement('li');
    newFilm.textContent = `${title} - ${director} (${year}) [${genre}]`;

    filmList.appendChild(newFilm);

    // Form törlése
    document.getElementById('film-form').reset();
});