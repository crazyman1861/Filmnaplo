document.addEventListener('DOMContentLoaded',()=>{
    const yearSpan = document.getElementById('year');

    function yearChange(){
        const date= new Date();

        yearSpan.textContent=date.getFullYear();
    }
    yearChange();
});