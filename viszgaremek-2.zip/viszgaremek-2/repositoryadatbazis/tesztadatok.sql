
INSERT INTO users (username,password_hash,email,created_at,is_admin)
VALUES("bubovics","StrongPassword2025","Bubovics1312@gmail.com","2024.10.08.",0);

INSERT INTO film_logs (user_id,title,release_year,genre,director,review,created_at)
VALUES(LAST_INSERT_ID(),"Avengers Endgame",2019,"Action Drama","Anthony russo","I loved it very much","2020.10.10.");

