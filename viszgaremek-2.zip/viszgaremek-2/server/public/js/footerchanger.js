document.addEventListener('DOMContentLoaded',()=>{
    const yearSpan = document.getElementById('footer-year');

    function yearChange(){
        const date= new Date();

        yearSpan.textContent=date.getFullYear();
    }
    yearChange();
});