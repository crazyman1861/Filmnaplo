document.addEventListener('DOMContentLoaded',()=>{
    document.getElementById('logout').addEventListener('click',()=>{
            localStorage.removeItem('token');
            window.location.href="/index.html";
    });
});
document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');

    if (!token) {
        alert('Nincs jogosultság a profil megtekintésére.');
        window.location.href = '/login.html';
        return;
    }

    async function updateProfile(endpoint, body) {
        try {
            const response = await fetch(endpoint, {
                method: 'PUT',
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(body)
            });

            if (!response.ok) {
                throw new Error('Hiba történt a profil frissítésekor.');
            }

            alert('Profil sikeresen frissítve!');
        } catch (error) {
            console.error('Hiba:', error);
            alert('Nem sikerült frissíteni a profilt.');
        }
    }

    document.querySelector('#username-changer-div form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const newUsername = e.target.querySelector('input').value;
        await updateProfile('/profile/username', { username: newUsername });
    });

    document.querySelector('#email-changer-div form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const newEmail = e.target.querySelector('input').value;
        await updateProfile('/profile/email', { email: newEmail });
    });

    document.querySelector('#password-changer-div form').addEventListener('submit', async (e) => {
        e.preventDefault();
        const newPassword = e.target.querySelector('input').value;
        await updateProfile('/profile/password', { password: newPassword });
    });

    try {
        const response = await fetch('/profile', {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });

        if (!response.ok) {
            throw new Error('Hiba történt a profil lekérésekor.');
        }

        const data = await response.json();
        document.getElementById('usernamediv').innerHTML += `<p>${data.username}</p>`;
        document.getElementById('emaildiv').innerHTML += `<p>${data.email}</p>`;

    } catch (error) {
        console.error('Hiba:', error);
        alert('Nem sikerült betölteni a profil adatait.');
    }

    document.getElementById('logout').addEventListener('click', () => {
        localStorage.removeItem('token');
        window.location.href = '/login.html';
    });
});
