// Ellenőrzés, hogy be van-e jelentkezve a felhasználó
const token = localStorage.getItem('token') || sessionStorage.getItem('token');

document.addEventListener('DOMContentLoaded', () => {
    fetch('/film-recommendation')
        .then(response => response.json())
        .then(data => {
            const filmSection = document.getElementById('film-recommendation-section');

            data.forEach(films => {
                filmSection.innerHTML += `
                    <div class="card h-100 col-12 col-md-4 mb-4">
                        <img class="card-img-top" src="/static/img/pics/${films.pic_url}" alt="StarWars" height="190" width="270">
                        <div class="card-body">
                            <h4>${films.title}</h4>
                            <p>${films.content}<br><strong>${films.genre}</strong></p>
                            ${token ? `<button class="custom-btn" onclick="likeFilm(${films.id})"><img src="/static/img/like.png" height="16px"></button>` : ''}
                        </div>
                        
                    </div>`;
            });
        })
        .catch(error => console.log('Hiba a lekérdezésnél', error));
});

document.addEventListener('DOMContentLoaded', () => {
    fetch('/series-recommendation')
        .then(response => response.json())
        .then(data => {
            const seriesSection = document.getElementById('series-recommendation-section');

            data.forEach(series => {
                seriesSection.innerHTML += `
                    <div class="card h-100 col-12 col-md-4 mb-4">
                        <img class="card-img-top" src="/static/img/pics/${series.pic_url}" alt="penzrablas" height="190" width="270">
                        <div class="card-body">
                            <h4>${series.title}</h4>
                            <p>${series.content}<br><strong>${series.genre}</strong></p>
                            ${token ? `<button class="custom-btn" onclick="likeSeries(${series.id})"><img src="/static/img/like.png" height="16px"></button>` : ''}
                        </div>
                        
                    </div>`;
            });
        })
        .catch(error => console.log('Hiba a lekérdezés során: ', error));
});

async function likeFilm(filmId) {
    try {
        const response = await fetch('/like-film', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}` // Token betöltése
            },
            body: JSON.stringify({ film_id: filmId })
        });

        const data = await response.json();
        if (!response.ok) {
            alert(`Hiba: ${data.error || 'Ismeretlen hiba történt.'}`);
        } else {
            alert(data.message || 'Sikeresen like-oltad a filmet!');
        }
    } catch (error) {
        console.error('Hiba a film like-olásánál:', error);
        alert('Hiba történt a szerverhez való kapcsolódás során.');
    }
}

async function likeSeries(seriesId) {
    try {
        const response = await fetch('/like-series', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}` // Token betöltése
            },
            body: JSON.stringify({ series_id: seriesId })
        });

        const data = await response.json();
        if (!response.ok) {
            alert(`Hiba: ${data.error || 'Ismeretlen hiba történt.'}`);
        } else {
            alert(data.message || 'Sikeresen like-oltad a sorozatot!');
        }
    } catch (error) {
        console.error('Hiba a sorozat like-olásánál:', error);
        alert('Hiba történt a szerverhez való kapcsolódás során.');
    }
}
