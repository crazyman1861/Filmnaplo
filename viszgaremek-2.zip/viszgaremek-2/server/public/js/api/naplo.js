document.getElementById('filmcreate').addEventListener('submit', async (event) => {
    event.preventDefault();

    const token = localStorage.getItem('token');
    if (!token) {
        alert('Be kell jelentkezned a film hozzáadásához.');
        return;
    }

    const title = document.getElementById('film-title').value;
    const director = document.getElementById('director').value;
    const year = document.getElementById('year').value;
    const genre = document.getElementById('genre').value;
    const rating = document.querySelector('input[name="rating"]:checked').value;

    const response = await fetch('/add-film', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ title, director, year, genre, rating })
    });

    const result = await response.json();
    if (response.ok) {
        alert('Film sikeresen hozzáadva!');
        addFilmToList(title, rating);
    } else {
        alert(result.error);
    }
});

const addFilmToList = (title, director, genre,rating) => {
    const filmCollection = document.getElementById('film-collection');
    const filmItem = document.createElement('li');
    filmItem.textContent = `${title} - ${director} - ${genre} - ${rating}★`;
    filmCollection.appendChild(filmItem);
};

document.addEventListener('DOMContentLoaded', async () => {
    const token = localStorage.getItem('token');
    if (!token) return;

    const response = await fetch('/get-films', {
        headers: {
            'Authorization': `Bearer ${token}`
        }
    });
    const films = await response.json();

    films.forEach(film => {
        addFilmToList(film.title,film.director,film.genre, film.rating);
    });
});
