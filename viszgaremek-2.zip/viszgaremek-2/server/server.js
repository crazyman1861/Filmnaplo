const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2');
const path = require('path');
const cors = require('cors');

const app = express();
app.use(express.json());
app.use(cors());
const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'filmnaplo'
});

conn.connect(err => {
    if (err) throw err;
    console.log('MySQL connected...');
});

app.use('/static', express.static(path.join(__dirname, 'public')));

const servePage = (page) => (req,res) => res.sendFile(path.join(__dirname, 'public', 'html', `${page}.html`));

app.get('/', servePage('index'));
app.get('/login.html', servePage('login'));
app.get('/felkapot.html', servePage('felkapot'));
app.get('/naplo.html', servePage('naplo'));
app.get('/registration.html', servePage('registration'));
app.get('/index.html', servePage('index'));
app.get('/profil.html', servePage('profil'));

const queryFunction = (res, query, params = []) => {
    conn.query(query, params, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        res.json(results.length === 1 ? results[0] : results);
    });
};
const authenticateToken = (req, res, next) => {
    const token = req.header('Authorization')?.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Access denied' });
    }

    jwt.verify(token, 'secret', (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Invalid token' });
        }

        req.user = user;
        next();
    });
};
app.get('/film-recommendation', (req, res) => {
    queryFunction(res, 'SELECT * FROM film_recommendation ORDER BY RAND() LIMIT 3');
});
app.get('/series-recommendation', (req, res) => {
    queryFunction(res, 'SELECT * FROM series_recommendation ORDER BY RAND() LIMIT 3');
});
// Filmek rangsorolása like-ok alapján
app.get('/ranked-films', (req, res) => {
    const query = `
        SELECT f.id, f.title, COUNT(fl.id) AS like_count, f.content, f.genre, f.pic_url
        FROM film_recommendation AS f
        LEFT JOIN film_likes AS fl ON f.id = fl.filmId
        GROUP BY f.id, f.title
        ORDER BY like_count DESC
        LIMIT 3
    `;
    queryFunction(res, query);
});

// Sorozatok rangsorolása like-ok alapján
app.get('/ranked-series', (req, res) => {
    const query = `
        SELECT s.id, s.title, COUNT(sl.id) AS like_count, s.content, s.genre, s.pic_url
        FROM series_recommendation AS s
        LEFT JOIN series_likes AS sl ON s.id = sl.seriesId
        GROUP BY s.id, s.title
        ORDER BY like_count DESC
        LIMIT 3
    `;
    queryFunction(res, query);
});

app.post('/add-film', authenticateToken, (req, res) => {
    const { title, director, year, genre, rating } = req.body;
    const userId = req.user.id;
    const date = new Date();

    const query = 'INSERT INTO film_diary (userId, title, director, date, genre, rating) VALUES (?, ?, ?, ?, ?, ?)';
    const params = [userId, title, director, date, genre, rating];

    queryFunction(res, query, params);
});
app.get('/get-films', authenticateToken, (req, res) => {
    const userId = req.user.id;

    const query = 'SELECT  * FROM film_diary WHERE userId = ?';
    const params = [userId];

    queryFunction(res, query, params);
});
// Film like hozzáadása
app.post('/like-film', authenticateToken, (req, res) => {
    const { film_id } = req.body;
    const userId = req.user.id;

    const checkQuery = 'SELECT * FROM film_likes WHERE userId = ? AND filmId = ?';
    const checkParams = [userId, film_id];

    conn.query(checkQuery, checkParams, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        
        if (results.length > 0) {
            return res.status(400).json({ error: 'Már like-oltad ezt a filmet.' });
        }

        const insertQuery = 'INSERT INTO film_likes (userId, filmId) VALUES (?, ?)';
        const insertParams = [userId, film_id];

        conn.query(insertQuery, insertParams, (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: 'Film like-olása sikeres.' });
        });
    });
});

// Sorozat like hozzáadása
app.post('/like-series', authenticateToken, (req, res) => {
    const { series_id } = req.body;
    const userId = req.user.id;

    const checkQuery = 'SELECT * FROM series_likes WHERE userId = ? AND seriesId = ?';
    const checkParams = [userId, series_id];

    conn.query(checkQuery, checkParams, (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        
        if (results.length > 0) {
            return res.status(400).json({ error: 'Már like-oltad ezt a sorozatot.' });
        }

        const insertQuery = 'INSERT INTO series_likes (userId, seriesId) VALUES (?, ?)';
        const insertParams = [userId, series_id];

        conn.query(insertQuery, insertParams, (err) => {
            if (err) return res.status(500).json({ error: err.message });
            res.json({ message: 'Sorozat like-olása sikeres.' });
        });
    });
});

app.post('/register', async (req, res) => {
    const { username, email, password, confirmPassword } = req.body;

    if (password !== confirmPassword) {
        return res.status(400).json({ error: "Passwords do not match" });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const query = 'INSERT INTO users (username, email, password, permission) VALUES (?, ?, ?, ?)';
    const params = [username, email, hashedPassword, 2];

    queryFunction(res, query, params);
});
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    const query = 'SELECT * FROM users WHERE username = ?';
    const params = [username];

    conn.query(query, params, async (err, results) => {
        if (err) return res.status(500).json({ error: err.message });
        if (results.length === 0) return res.status(400).json({ error: 'User not found' });

        const user = results[0];
        const isPasswordValid = await bcrypt.compare(password, user.password);

        if (!isPasswordValid) {
            return res.status(400).json({ error: 'Invalid password' });
        }

        const token = jwt.sign({ id: user.id, username: user.username, permission: user.permission }, 'secret', { expiresIn: '1h' });

        res.json({ token });
    });
});
app.get('/profile', authenticateToken, (req, res) => {
    const query = 'SELECT username, email, permission FROM users WHERE id = ?';

    queryFunction(res, query, [req.user.id]);
});
// Felhasználónév módosítása
app.put('/profile/username', authenticateToken, (req, res) => {
    const { username } = req.body;
    const query = 'UPDATE users SET username = ? WHERE id = ?';

    queryFunction(res, query, [username, req.user.id]);
});

// Email cím módosítása
app.put('/profile/email', authenticateToken, (req, res) => {
    const { email } = req.body;
    const query = 'UPDATE users SET email = ? WHERE id = ?';

    queryFunction(res, query, [email, req.user.id]);
});

// Jelszó módosítása
app.put('/profile/password', authenticateToken, (req, res) => {
    const { password } = req.body;
    const query = 'UPDATE users SET password = ? WHERE id = ?';

    queryFunction(res, query, [password, req.user.id]);
});

app.listen(3000, () => {
    console.log('Server running on port 3000');
});
