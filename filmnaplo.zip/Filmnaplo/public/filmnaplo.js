function veletlen() {
    fetch('http://localhost:3000/velemeny')
        .then(response => {
            if (!response.ok) {
                throw new Error('Hiba történt a GET kérés során');
            }
            return response.json();
        })
        .then(data => {
            const korabbiDiv = document.getElementById('korabbi');
            if (data.length > 0) {
                const randomVelemeny = data[0]; 
                korabbiDiv.innerHTML = `
                    <p><strong>${randomVelemeny.nev}</strong></p>
                    <p>${randomVelemeny.velemeny}</p>
                `;
            } else {
                korabbiDiv.innerHTML = '<p>Még nem érkezett vélemény.</p>';
            }
        })
        .catch(error => {
            console.error('Hiba történt a GET kérés során:', error);
            document.getElementById('korabbi').innerHTML = '<p>Hiba történt a vélemények betöltésekor.</p>';
        });
}

document.addEventListener('DOMContentLoaded', veletlen);

// A POST kérés a vélemény beküldésére
function kuldes() {
    const nev = document.getElementById("nev").value;
    const velemeny = document.getElementById("velemenyInput").value;

    // Ellenőrizzük, hogy mindkét mező ki van-e töltve
    if (!nev || !velemeny) {
        alert("Kérjük, adja meg nevét és véleményét!");
        return;
    }

    fetch('http://localhost:3000/velemeny', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',  // Fontos, hogy JSON-ként küldjük
        },
        body: JSON.stringify({
            nev: nev,  // A név és vélemény adatokat JSON formátumban küldjük
            velemeny: velemeny
        })
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Hiba történt a POST kérés során');
        }
        return response.json();
    })
    .then(data => {
        console.log('Sikeres beküldés:', data);
        // Miután sikeresen elküldtük, töröljük az űrlap adatokat
        document.getElementById("nev").value = '';
        document.getElementById("velemenyInput").value = '';
        alert('Köszönjük!');
        veletlen();  // Frissítjük a korábbi véleményt
    })
    .catch(error => {
        console.log('Hiba történt a POST kérés során:', error);
    });
}
document.getElementById("gomb").addEventListener("click", kuldes);