  // "Elfelejtett jelszó?" link kezelése
  document.getElementById("forgot-password-link").addEventListener("click", function(e) {
    e.preventDefault();
    document.querySelector(".login-form").style.display = "none";
    document.getElementById("reset-container").style.display = "block";
});

// "Vissza a bejelentkezéshez" link kezelése
document.getElementById("back-to-login-link").addEventListener("click", function(e) {
    e.preventDefault();
    document.querySelector(".login-form").style.display = "block";
    document.getElementById("reset-container").style.display = "none";
});

// E-mail küldése
document.getElementById("email-form").addEventListener("submit", function(e) {
    e.preventDefault();
    alert("A kódot elküldtük az e-mail címére.");
    document.getElementById("reset-container").style.display = "none";
    document.getElementById("verify-container").style.display = "block";
});

// "Vissza az e-mail küldéshez" link kezelése
document.getElementById("back-to-reset-link").addEventListener("click", function(e) {
    e.preventDefault();
    document.getElementById("verify-container").style.display = "none";
    document.getElementById("reset-container").style.display = "block";
});

// Kód ellenőrzése
document.getElementById("verify-form").addEventListener("submit", function(e) {
    e.preventDefault();
    const code = document.querySelector("input[name='verification-code']").value;
    if (code === "123456") { // Példa kód ellenőrzéshez
        alert("A kód helyes. Visszaállíthatja a jelszót.");
        document.getElementById("verify-container").style.display = "none";
        document.getElementById("new-password-container").style.display = "block";
    } else {
        alert("Helytelen kód. Kérjük, próbálja újra.");
    }
});

// Új jelszó beállítása
document.getElementById("new-password-form").addEventListener("submit", function(e) {
    e.preventDefault();
    const newPassword = document.querySelector("input[name='new-password']").value;
    const confirmPassword = document.querySelector("input[name='confirm-password']").value;

    if (newPassword !== confirmPassword) {
        alert("A jelszavak nem egyeznek. Kérjük, próbálja újra.");
        return;
    }

    alert("Jelszó sikeresen módosítva!");
    document.getElementById("new-password-container").style.display = "none";
    document.querySelector(".login-form").style.display = "block";
});

// "Vissza a kódhoz" link kezelése
document.getElementById("back-to-code-link").addEventListener("click", function(e) {
    e.preventDefault();
    document.getElementById("new-password-container").style.display = "none";
    document.getElementById("verify-container").style.display = "block";
});