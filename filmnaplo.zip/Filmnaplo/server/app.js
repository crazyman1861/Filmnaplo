const express = require('express');
const mysql = require('mysql');
const cors = require('cors');  // CORS csomag importálása

const app = express();
const port = 3000;
app.use(express.json()); 
app.use(express.static('public'));

app.use(cors({
    origin: 'http://localhost:5500',  // Csak a Live Server portját engedélyezi
    methods: ['GET', 'POST'],
    allowedHeaders: ['Content-Type']
}));

// Kapcsolódás MySQL adatbázishoz
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'oldtimer'
});

// MySQL kapcsolat
db.connect((err) => {
    if (err) {
        console.error('Hiba történt a MySQL adatbázishoz való kapcsolódás során: ' + err.stack);
        return;
    }
    console.log('Kapcsolódva a MySQL adatbázishoz, id: ' + db.threadId);
});


// POST kérés
app.post('/velemeny', (req, res) => {
    const { nev, velemeny} = req.body;

    if (!nev || !velemeny) {
        return res.status(400).json({ error: 'A név és vélemény megadása kötelező!' });
    }

    const query = 'INSERT INTO velemenyek (nev, velemeny) VALUES (?, ?)';
    
    db.query(query, [nev, velemeny], (err, result) => {
        if (err) {
            console.error('Hiba történt a rekord beszúrása során:', err);
            return res.status(500).json({ error: 'Hiba történt a vélemény hozzáadása során' });
        }
        res.status(201).json({ message: 'Vélemény sikeresen hozzáadva!' });
    });
});

// Kérés kezelése
app.get('/velemeny', (req, res) => {
    const query = 'SELECT * FROM velemenyek';

    db.query(query, (err, results) => {
        if (err) {
            console.error('Hiba történt a lekérdezés során:', err);
            return res.status(500).json({ error: 'Hiba történt a vélemények lekérésekor' });
        }

        if (results.length > 0) {
            const randomIndex = Math.floor(Math.random() * results.length);
            res.json([results[randomIndex]]);
        } else {
            res.json([]);
        }
    });
});


// Indítja a szervert
app.listen(3000, () => {
    console.log('Szerver fut a 3000-es porton');
});
